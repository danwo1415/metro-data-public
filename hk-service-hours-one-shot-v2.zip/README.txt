Upload this ZIP to the root of metro-data-public, then run:

unzip -o hk-service-hours-one-shot-v2.zip
rm -f hk-service-hours-one-shot-v2.zip
bash RUN-ONCE.sh

The script installs Chromium system dependencies, writes a persistent log, validates the generated JSON, commits, rebases, and pushes.

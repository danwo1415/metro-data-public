#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
LOG=service-hours-run.log
exec > >(tee "$LOG") 2>&1
trap 'code=$?; echo "FAILED: exit=$code"; echo "See $LOG"; exit $code' ERR

echo "[1/6] Cleaning old test files"
rm -rf __pycache__ cell-debug.txt mtr-station-test.html mtr-style-*.css mtr-script-*.js station-search.txt test_mtr_station.py service-hours-report.json

echo "[2/6] Installing Python package"
python -m pip install --quiet --upgrade pip
python -m pip install --quiet playwright

echo "[3/6] Installing Chromium and Linux dependencies"
python -m playwright install --with-deps chromium

echo "[4/6] Importing official MTR service hours"
python -u update_hk_service_hours.py

echo "[5/6] Validating output"
python -m json.tool hong-kong-data.json >/dev/null
python -m json.tool version.json >/dev/null
python -m json.tool service-hours-report.json >/dev/null
python - <<'PY'
import json
with open('service-hours-report.json', encoding='utf-8') as f:
    r=json.load(f)
print(f"VALIDATED: stations={r.get('stations')} records={r.get('records')} errors={len(r.get('errors', []))} unresolved={len(r.get('unresolved', []))}")
PY

echo "[6/6] Committing and pushing"
git add hong-kong-data.json version.json service-hours-report.json update_hk_service_hours.py RUN-ONCE.sh service-hours-run.log
git commit -m "Import Hong Kong official first and last train data" || true
git pull --rebase origin main
git push origin main

echo "DONE: data updated and pushed. Reopen the app, then tap refresh."

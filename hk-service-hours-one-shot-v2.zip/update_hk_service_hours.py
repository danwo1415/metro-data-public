#!/usr/bin/env python3
import json, re, sys, time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode

DATA = Path('hong-kong-data.json')
VERSION = Path('version.json')
REPORT = Path('service-hours-report.json')
BASE = 'https://www.mtr.com.hk/en/customer/services/service_hours_search.php'

LINE_EN = {
 'AEL':'Airport Express','TCL':'Tung Chung Line','TML':'Tuen Ma Line',
 'EAL':'East Rail Line','TWL':'Tsuen Wan Line','ISL':'Island Line',
 'KTL':'Kwun Tong Line','TKL':'Tseung Kwan O Line','SIL':'South Island Line',
 'DRL':'Disneyland Resort Line'
}
ALIASES = {
 'hong kong university':'hku', 'university of hong kong':'hku',
 'asia world expo':'asiaworld expo', 'asiaworldexpo':'asiaworld expo',
 'exhibition centre station':'exhibition centre',
 'lo wu station':'lo wu', 'lok ma chau station':'lok ma chau',
 'disneyland resort station':'disneyland resort',
}
TIME_RE = re.compile(r'^(?:[01]?\d|2[0-3]):?[0-5]\d$')

def norm(s):
    s = (s or '').lower().replace('&',' and ')
    s = re.sub(r'\b(to|towards|direction|station)\b',' ',s)
    s = re.sub(r'[^a-z0-9]+',' ',s).strip()
    return ALIASES.get(s, s)

def hhmm(s):
    s = re.sub(r'\D','',s or '')
    if len(s)==3: s='0'+s
    if len(s)!=4: raise ValueError(f'bad time {s!r}')
    h,m=int(s[:2]),int(s[2:])
    if h>23 or m>59: raise ValueError(f'bad time {s!r}')
    return f'{h:02d}:{m:02d}'

def station_maps(data):
    code_to_en = data.get('english',{})
    name_to_code = {}
    for code,name in code_to_en.items():
        name_to_code[norm(name)] = code
    # Useful official variants.
    extra = {
      'hku':'HKU','asiaworld expo':'AWE','exhibition centre':'EXC',
      'disneyland resort':'DIS','ocean park':'OCP','south horizons':'SOH',
      'lei tung':'LET','wong chuk hang':'WCH','ho man tin':'HOM',
      'sung wong toi':'SUW','to kwa wan':'TKW','tuen mun':'TUM',
      'wu kai sha':'WKS','lok ma chau':'LMC','lo wu':'LOW',
      'racecourse':'RAC','po lam':'POA','loh as park':'LHP','lohas park':'LHP'
    }
    name_to_code.update(extra)
    return code_to_en, name_to_code

def line_station_sets(data):
    return {k:{x[0] for x in v['stations']} for k,v in data['L'].items()}

def choose_line(current, dest, context, line_sets):
    ctext = norm(context)
    for code,name in LINE_EN.items():
        if norm(name) in ctext:
            return code
    candidates=[code for code,s in line_sets.items() if current in s and dest in s]
    if len(candidates)==1: return candidates[0]
    # Shared AEL/TCL trunk: table context usually resolves it; otherwise use keywords/classes.
    raw=context.lower()
    for code in candidates:
        if code.lower() in raw: return code
    return None

def bump_version(v):
    old=v.get('hongKongDataVersion',1)
    try: old=int(old)
    except Exception: old=1
    v['hongKongDataVersion']=old+1
    v['updatedAt']=datetime.now(timezone.utc).date().isoformat()
    v['dataUrl']='https://raw.githubusercontent.com/danwo1415/metro-data-public/main/hong-kong-data.json'

def main():
    if not DATA.exists() or not VERSION.exists():
        sys.exit('ERROR: run this in metro-data-public; hong-kong-data.json/version.json missing')
    data=json.loads(DATA.read_text(encoding='utf-8'))
    version=json.loads(VERSION.read_text(encoding='utf-8'))
    code_to_en,name_to_code=station_maps(data)
    line_sets=line_station_sets(data)

    try:
        from playwright.sync_api import sync_playwright
    except Exception:
        sys.exit('ERROR: playwright missing. Run: python -m pip install playwright && python -m playwright install chromium')

    report={'startedAt':datetime.now(timezone.utc).isoformat(),'pages':0,'records':0,'stations':0,'unresolved':[],'errors':[]}
    service={}
    print('Starting official MTR service-hours import...', flush=True)
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True, args=['--no-sandbox','--disable-dev-shm-usage'])
        page=browser.new_page(user_agent='Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/130 Safari/537.36')
        page.goto(BASE+'?'+urlencode({'query_type':'search','station':'1'}),wait_until='domcontentloaded',timeout=60000)
        page.wait_for_timeout(1200)
        options=page.locator('select option').evaluate_all("els => els.map(e => ({value:e.value, text:(e.innerText||e.textContent||'').trim()}))")
        numeric=[]
        for o in options:
            if str(o['value']).isdigit(): numeric.append((int(o['value']),o['text']))
        numeric=sorted(set(numeric))
        if len(numeric)<50:
            # Fallback covers current network IDs without assuming exact count.
            numeric=[(i,'') for i in range(1,131)]
        print(f'Discovered {len(numeric)} candidate station pages', flush=True)

        for pos,(sid,hint) in enumerate(numeric,1):
            url=BASE+'?'+urlencode({'query_type':'search','station':sid})
            try:
                page.goto(url,wait_until='domcontentloaded',timeout=45000)
                page.wait_for_timeout(350)
                rows=page.locator('tr:has(td.firstTrain)').evaluate_all("""rows => rows.map(r => {
                  const cells=[...r.querySelectorAll(':scope > th, :scope > td')];
                  const ancestors=[]; let n=r;
                  for(let i=0;i<5 && n;i++,n=n.parentElement){ancestors.push((n.innerText||'')+' '+(n.className||''));}
                  return {cells:cells.map(c=>({text:(c.innerText||c.textContent||'').trim(), cls:c.className||'', html:c.innerHTML})), context:ancestors.join(' | ')};
                })""")
                if not rows:
                    continue
                report['pages']+=1
                # Current station: selected option, heading, then hint.
                current_text=page.locator('select option:checked').first.text_content() if page.locator('select option:checked').count() else ''
                if not current_text:
                    current_text=hint
                current=name_to_code.get(norm(current_text))
                if not current:
                    # Match any known official English name visible near page heading.
                    body_head=page.locator('body').inner_text()[:2500]
                    matches=[(len(nm),code) for nm,code in name_to_code.items() if nm and nm in norm(body_head)]
                    current=max(matches)[1] if matches else None
                if not current:
                    report['unresolved'].append({'stationId':sid,'type':'current','text':current_text})
                    continue

                before=report['records']
                for row in rows:
                    cells=row['cells']
                    ft_idx=next((i for i,c in enumerate(cells) if 'firstTrain' in c['cls']),None)
                    if ft_idx is None or ft_idx+1>=len(cells): continue
                    try: first,last=hhmm(cells[ft_idx]['text']),hhmm(cells[ft_idx+1]['text'])
                    except Exception: continue
                    direction_text=' '.join(c['text'] for c in cells[:ft_idx] if c['text']).strip()
                    # Rendered localization text may be inside the empty span after JS; read row text too.
                    if not direction_text:
                        m=re.search(r'js_station_(\d+)', ' '.join(c['html'] for c in cells[:ft_idx]))
                        if m:
                            cls='js_station_'+m.group(1)
                            loc=page.locator('.'+cls).first
                            if loc.count(): direction_text=(loc.inner_text() or loc.text_content() or '').strip()
                    dest=name_to_code.get(norm(direction_text))
                    if not dest:
                        report['unresolved'].append({'stationId':sid,'station':current,'type':'direction','text':direction_text,'row':cells})
                        continue
                    line=choose_line(current,dest,row['context']+' '+direction_text,line_sets)
                    if not line:
                        report['unresolved'].append({'stationId':sid,'station':current,'type':'line','destination':dest,'context':row['context'][:300]})
                        continue
                    service.setdefault(current,{}).setdefault(line,{})[dest]={'first':first,'last':last,'source':'MTR official service hours'}
                    report['records']+=1
                if report['records']>before: report['stations']+=1
                print(f'[{pos}/{len(numeric)}] {current or sid}: +{report["records"]-before}', flush=True)
            except Exception as exc:
                report['errors'].append({'stationId':sid,'error':str(exc)})
                print(f'[{pos}/{len(numeric)}] station {sid}: ERROR {exc}', flush=True)
        browser.close()

    report['finishedAt']=datetime.now(timezone.utc).isoformat()
    # Hard safety gate: never overwrite good data with a failed scrape.
    if report['stations']<60 or report['records']<100:
        REPORT.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        print(f'FAILED SAFETY CHECK: stations={report["stations"]}, records={report["records"]}', flush=True)
        print('Original hong-kong-data.json was NOT modified.', flush=True)
        sys.exit(2)

    data['serviceHours']=service
    data['updatedAt']=datetime.now(timezone.utc).date().isoformat()
    data['version']='2.4.1-hk-data-'+str(int(version.get('hongKongDataVersion',1))+1)
    bump_version(version)
    DATA.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    VERSION.write_text(json.dumps(version,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    REPORT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'SUCCESS: {report["stations"]} stations, {report["records"]} direction records', flush=True)
    print('Updated hong-kong-data.json and version.json', flush=True)

if __name__=='__main__':
    main()

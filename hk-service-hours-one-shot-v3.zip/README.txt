Hong Kong MTR service-hours updater v3

This version does not use Chromium or Playwright.
It reads the official HTML with requests, maps js_station_<id> using the station selector,
validates at least 80 stations and 150 direction records, then updates and pushes the JSON.

Run only:
  unzip -o hk-service-hours-one-shot-v3.zip
  rm -f hk-service-hours-one-shot-v3.zip
  bash RUN-ONCE.sh

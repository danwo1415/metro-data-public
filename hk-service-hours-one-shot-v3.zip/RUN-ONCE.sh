#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

python -m pip install --quiet requests beautifulsoup4 lxml
python -u update_hk_service_hours.py | tee service-hours-run.log
python -m json.tool hong-kong-data.json >/dev/null
python -m json.tool version.json >/dev/null
python -m json.tool service-hours-report.json >/dev/null

git add hong-kong-data.json version.json service-hours-report.json update_hk_service_hours.py RUN-ONCE.sh
git commit -m "Import official Hong Kong MTR service hours" || true
git pull --rebase origin main
git push origin main

echo "DONE: official Hong Kong service-hours data validated and pushed."

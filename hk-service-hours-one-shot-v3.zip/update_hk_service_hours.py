#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import shutil
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import requests
from bs4 import BeautifulSoup, Tag

DATA = Path("hong-kong-data.json")
VERSION = Path("version.json")
REPORT = Path("service-hours-report.json")
BASE = "https://www.mtr.com.hk/en/customer/services/service_hours_search.php"
UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/130 Safari/537.36"

ALIASES = {
    "asia world expo": "asiaworld expo",
    "asiaworldexpo": "asiaworld expo",
    "hong kong university": "hku",
    "university of hong kong": "hku",
    "exhibition centre station": "exhibition centre",
    "lo wu station": "lo wu",
    "lok ma chau station": "lok ma chau",
    "disneyland resort station": "disneyland resort",
    "ocean park station": "ocean park",
    "lohas park station": "lohas park",
}


def norm(value: str | None) -> str:
    text = (value or "").lower().replace("&", " and ")
    text = re.sub(r"\b(station|mtr|line)\b", " ", text)
    text = re.sub(r"[^a-z0-9]+", " ", text).strip()
    return ALIASES.get(text, text)


def hhmm(value: str) -> str:
    digits = re.sub(r"\D", "", value or "")
    if len(digits) == 3:
        digits = "0" + digits
    if len(digits) != 4:
        raise ValueError(f"invalid time: {value!r}")
    hour, minute = int(digits[:2]), int(digits[2:])
    if hour > 23 or minute > 59:
        raise ValueError(f"invalid time: {value!r}")
    return f"{hour:02d}:{minute:02d}"


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def atomic_write(path: Path, payload: dict[str, Any]) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temp.replace(path)


def station_name_map(data: dict[str, Any]) -> dict[str, str]:
    result = {norm(name): code for code, name in data.get("english", {}).items()}
    result.update({
        "hku": "HKU",
        "asiaworld expo": "AWE",
        "exhibition centre": "EXC",
        "disneyland resort": "DIS",
        "lohas park": "LHP",
        "lo wu": "LOW",
        "lok ma chau": "LMC",
    })
    return result


def line_sets(data: dict[str, Any]) -> dict[str, set[str]]:
    return {line: {station[0] for station in spec["stations"]} for line, spec in data["L"].items()}


def parse_options(soup: BeautifulSoup) -> dict[int, str]:
    found: dict[int, str] = {}
    for option in soup.select("select option[value]"):
        value = (option.get("value") or "").strip()
        if value.isdigit():
            name = option.get_text(" ", strip=True)
            if name:
                found[int(value)] = name
    return found


def destination_id(row: Tag, first_cell: Tag) -> int | None:
    cells = row.find_all(["th", "td"], recursive=False)
    try:
        first_index = cells.index(first_cell)
    except ValueError:
        first_index = len(cells)
    html = " ".join(str(cell) for cell in cells[:first_index])
    match = re.search(r"js_station_(\d+)", html)
    return int(match.group(1)) if match else None


def infer_line(current: str, destinations: list[str], sets: dict[str, set[str]]) -> str | None:
    unique_destinations = set(destinations)
    candidates = [
        line for line, stations in sets.items()
        if current in stations and unique_destinations and unique_destinations.issubset(stations)
    ]
    if len(candidates) == 1:
        return candidates[0]
    # If one row is shared by two lines, a unique terminal elsewhere in the same table normally resolves it.
    if len(candidates) > 1:
        scored = []
        for line in candidates:
            exclusive = sum(1 for dest in unique_destinations if sum(dest in s for s in sets.values()) == 1)
            scored.append((exclusive, line))
        scored.sort(reverse=True)
        if scored and (len(scored) == 1 or scored[0][0] > scored[1][0]):
            return scored[0][1]
    return None


def fetch(session: requests.Session, station_id: int) -> str:
    params = {"query_type": "search", "station": str(station_id)}
    last_error: Exception | None = None
    for attempt in range(4):
        try:
            response = session.get(BASE, params=params, timeout=35)
            response.raise_for_status()
            if "First Train" not in response.text or "Last Train" not in response.text:
                raise RuntimeError("unexpected MTR page content")
            return response.text
        except Exception as exc:
            last_error = exc
            time.sleep(1.2 * (attempt + 1))
    raise RuntimeError(f"station {station_id}: {last_error}")


def main() -> None:
    if not DATA.exists() or not VERSION.exists():
        sys.exit("ERROR: run in metro-data-public; hong-kong-data.json and version.json are required")

    data = load_json(DATA)
    manifest = load_json(VERSION)
    names = station_name_map(data)
    sets = line_sets(data)

    session = requests.Session()
    session.headers.update({"User-Agent": UA, "Accept-Language": "en-HK,en;q=0.9"})

    print("[1/4] Reading MTR station list...", flush=True)
    first_html = fetch(session, 1)
    first_soup = BeautifulSoup(first_html, "lxml")
    id_to_name = parse_options(first_soup)
    if len(id_to_name) < 80:
        sys.exit(f"ERROR: only {len(id_to_name)} station options found; no files changed")

    id_to_code: dict[int, str] = {}
    unresolved_options: list[dict[str, Any]] = []
    for station_id, name in id_to_name.items():
        code = names.get(norm(name))
        if code:
            id_to_code[station_id] = code
        else:
            unresolved_options.append({"stationId": station_id, "name": name})

    report: dict[str, Any] = {
        "startedAt": datetime.now(timezone.utc).isoformat(),
        "stationOptions": len(id_to_name),
        "mappedOptions": len(id_to_code),
        "stationsWithData": 0,
        "records": 0,
        "unresolvedOptions": unresolved_options,
        "unresolvedRows": [],
        "errors": [],
    }
    service: dict[str, Any] = {}

    print(f"[2/4] Fetching {len(id_to_name)} official station pages...", flush=True)
    for index, station_id in enumerate(sorted(id_to_name), 1):
        current = id_to_code.get(station_id)
        if not current:
            continue
        try:
            html = first_html if station_id == 1 else fetch(session, station_id)
            soup = BeautifulSoup(html, "lxml")
            before = report["records"]

            for table in soup.find_all("table"):
                parsed_rows: list[dict[str, Any]] = []
                table_destinations: list[str] = []
                for row in table.find_all("tr"):
                    first = row.find("td", class_=lambda c: c and "firstTrain" in c)
                    if first is None:
                        continue
                    cells = row.find_all(["th", "td"], recursive=False)
                    try:
                        first_index = cells.index(first)
                    except ValueError:
                        continue
                    if first_index + 1 >= len(cells):
                        continue
                    dest_id = destination_id(row, first)
                    dest = id_to_code.get(dest_id) if dest_id is not None else None
                    try:
                        first_time = hhmm(first.get_text(" ", strip=True))
                        last_time = hhmm(cells[first_index + 1].get_text(" ", strip=True))
                    except ValueError:
                        continue
                    parsed_rows.append({
                        "destId": dest_id,
                        "dest": dest,
                        "first": first_time,
                        "last": last_time,
                    })
                    if dest:
                        table_destinations.append(dest)

                if not parsed_rows:
                    continue
                line = infer_line(current, table_destinations, sets)
                if not line:
                    report["unresolvedRows"].append({
                        "stationId": station_id,
                        "station": current,
                        "destinations": table_destinations,
                        "reason": "line not uniquely inferred",
                    })
                    continue

                for item in parsed_rows:
                    dest = item["dest"]
                    if not dest:
                        report["unresolvedRows"].append({
                            "stationId": station_id,
                            "station": current,
                            "destId": item["destId"],
                            "reason": "destination not mapped",
                        })
                        continue
                    service.setdefault(current, {}).setdefault(line, {})[dest] = {
                        "first": item["first"],
                        "last": item["last"],
                        "source": "MTR official service hours",
                    }
                    report["records"] += 1

            if report["records"] > before:
                report["stationsWithData"] += 1
            print(
                f"  [{index:02d}/{len(id_to_name)}] {current}: +{report['records'] - before}",
                flush=True,
            )
        except Exception as exc:
            report["errors"].append({"stationId": station_id, "station": current, "error": str(exc)})
            print(f"  [{index:02d}/{len(id_to_name)}] {current}: ERROR {exc}", flush=True)

    report["finishedAt"] = datetime.now(timezone.utc).isoformat()
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(
        f"[3/4] Validating: stations={report['stationsWithData']}, records={report['records']}, errors={len(report['errors'])}",
        flush=True,
    )
    if report["stationsWithData"] < 80 or report["records"] < 150:
        sys.exit("ERROR: safety threshold not met; hong-kong-data.json and version.json were not changed")

    now = datetime.now(timezone.utc).date().isoformat()
    old_version = str(manifest.get("version") or "2.4.1-hk-data-1")
    match = re.search(r"^(.*?)(\d+)$", old_version)
    if match:
        new_version = match.group(1) + str(int(match.group(2)) + 1)
    else:
        new_version = old_version + "-2"

    data["serviceHours"] = service
    data["updatedAt"] = now
    data["version"] = new_version
    manifest["version"] = new_version
    manifest["updatedAt"] = now
    manifest["dataUrl"] = "https://raw.githubusercontent.com/danwo1415/metro-data-public/main/hong-kong-data.json"

    shutil.copy2(DATA, DATA.with_suffix(".json.bak"))
    shutil.copy2(VERSION, VERSION.with_suffix(".json.bak"))
    atomic_write(DATA, data)
    atomic_write(VERSION, manifest)
    print(f"[4/4] SUCCESS: version={new_version}", flush=True)
    print("Updated hong-kong-data.json, version.json and service-hours-report.json", flush=True)


if __name__ == "__main__":
    main()

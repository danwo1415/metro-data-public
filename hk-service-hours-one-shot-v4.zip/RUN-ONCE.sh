#!/usr/bin/env bash
set -euo pipefail
python -m pip install -q requests beautifulsoup4 lxml
python -u update_hk_service_hours.py
python -m json.tool hong-kong-data.json >/dev/null
python -m json.tool version.json >/dev/null
git add hong-kong-data.json version.json service-hours-report.json update_hk_service_hours.py RUN-ONCE.sh
git commit -m "Update Hong Kong official first and last train data" || true
git pull --rebase origin main
git push origin main
echo "DONE: official Hong Kong service-hours data updated and pushed."

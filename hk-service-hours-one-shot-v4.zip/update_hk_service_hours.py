#!/usr/bin/env python3
import json,re,sys,time
from pathlib import Path
from urllib.parse import urljoin
import requests
from bs4 import BeautifulSoup

BASE='https://www.mtr.com.hk/en/customer/services/service_hours_search.php'
DATA=Path('hong-kong-data.json'); VERSION=Path('version.json'); REPORT=Path('service-hours-report.json')
UA='Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/130 Safari/537.36'

def norm(s):
    s=(s or '').lower().replace('&',' and ')
    s=re.sub(r'\b(station|mtr|line)\b',' ',s)
    return re.sub(r'[^a-z0-9]+',' ',s).strip()

def hhmm(s):
    d=re.sub(r'\D','',s or '')
    if len(d)==3:d='0'+d
    if len(d)!=4: raise ValueError(s)
    h,m=int(d[:2]),int(d[2:])
    if h>23 or m>59: raise ValueError(s)
    return f'{h:02d}:{m:02d}'

def get(session,url,**kw):
    for i in range(4):
        try:
            r=session.get(url,timeout=35,**kw); r.raise_for_status(); return r.text
        except Exception:
            if i==3: raise
            time.sleep(1+i)

def extract_mapping_from_assets(session,html):
    soup=BeautifulSoup(html,'lxml')
    urls=[]
    for t in soup.select('script[src]'):
        urls.append(urljoin(BASE,t.get('src')))
    seen=set(); texts=[]
    while urls and len(seen)<80:
        u=urls.pop(0)
        if u in seen: continue
        seen.add(u)
        try: txt=get(session,u)
        except Exception: continue
        texts.append((u,txt))
        for p in re.findall(r'["\']([^"\']+\.js(?:\?[^"\']*)?)["\']',txt):
            nu=urljoin(u,p)
            if nu not in seen: urls.append(nu)
    out={}
    pats=[
      re.compile(r'js_station_(\d+)[^\n]{0,160}?(?:html|text)\s*\(\s*["\']([^"\']+)',re.I),
      re.compile(r'["\']js_station_(\d+)["\']\s*:\s*["\']([^"\']+)',re.I),
      re.compile(r'case\s+(\d+)\s*:\s*(?:return\s+)?["\']([^"\']+)["\']',re.I),
      re.compile(r'\b(\d{1,3})\s*:\s*["\']([A-Za-z][A-Za-z .\-\']{2,40})["\']')
    ]
    for _,txt in texts:
        for pat in pats:
            for a,b in pat.findall(txt):
                b=re.sub(r'<[^>]+>','',b).strip()
                if b and len(b)<60: out[int(a)]=b
    return out, [u for u,_ in texts]

def main():
    if not DATA.exists() or not VERSION.exists(): sys.exit('ERROR: missing hong-kong-data.json or version.json')
    data=json.loads(DATA.read_text(encoding='utf-8')); manifest=json.loads(VERSION.read_text(encoding='utf-8'))
    name_to_code={norm(v):k for k,v in data.get('english',{}).items()}
    name_to_code.update({'hku':'HKU','asiaworld expo':'AWE','exhibition centre':'EXC','disneyland resort':'DIS','lohas park':'LHP','lo wu':'LOW','lok ma chau':'LMC'})
    line_sets={k:{x[0] for x in v['stations']} for k,v in data['L'].items()}
    s=requests.Session(); s.headers.update({'User-Agent':UA,'Accept-Language':'en-HK,en;q=0.9'})
    print('[1/4] Reading official MTR mapping...',flush=True)
    first=get(s,BASE,params={'query_type':'search','station':'1'})
    id_to_name,assets=extract_mapping_from_assets(s,first)
    id_to_code={i:name_to_code.get(norm(n)) for i,n in id_to_name.items()}
    id_to_code={i:c for i,c in id_to_code.items() if c}
    if len(id_to_code)<80:
        Path('service-hours-debug.json').write_text(json.dumps({'mapped':id_to_code,'rawNames':id_to_name,'assets':assets},indent=2),encoding='utf-8')
        sys.exit(f'ERROR: only {len(id_to_code)} station names mapped; no files changed. See service-hours-debug.json')
    service={}; errors=[]; records=0; stations=0
    print(f'[2/4] Fetching {len(id_to_code)} station pages...',flush=True)
    for idx,sid in enumerate(sorted(id_to_code),1):
        current=id_to_code[sid]
        try:
            html=first if sid==1 else get(s,BASE,params={'query_type':'search','station':str(sid)})
            soup=BeautifulSoup(html,'lxml'); added=0
            for h2 in soup.select('h2.trainLine'):
                classes=h2.get('class') or []
                line=next((c for c in classes if c!='trainLine'),None)
                if line not in data['L']: continue
                table=h2.find_next('table')
                if not table: continue
                for tr in table.select('tr'):
                    ft=tr.select_one('td.firstTrain')
                    if not ft: continue
                    cells=tr.find_all('td',recursive=False)
                    if len(cells)<3: continue
                    m=re.search(r'js_station_(\d+)',str(cells[0]))
                    if not m: continue
                    dest=id_to_code.get(int(m.group(1)))
                    if not dest or dest not in line_sets[line]: continue
                    try: first_t,last_t=hhmm(ft.get_text()),hhmm(cells[-1].get_text())
                    except Exception: continue
                    service.setdefault(current,{}).setdefault(line,{})[dest]={'first':first_t,'last':last_t,'source':'MTR official service hours'}
                    records+=1; added+=1
            if added: stations+=1
            print(f'  [{idx:02d}/{len(id_to_code)}] {current}: +{added}',flush=True)
        except Exception as e:
            errors.append({'stationId':sid,'station':current,'error':str(e)})
    if stations<80 or records<150:
        REPORT.write_text(json.dumps({'stations':stations,'records':records,'errors':errors},indent=2),encoding='utf-8')
        sys.exit(f'ERROR: validation failed stations={stations} records={records}; no files changed')
    print('[3/4] Writing validated data...',flush=True)
    data['serviceHours']=service; data['updatedAt']='2026-08-02'; data['version']='2.4.1-hk-data-2'
    manifest['hongKongDataVersion']=int(manifest.get('hongKongDataVersion',1))+1; manifest['updatedAt']='2026-08-02'
    DATA.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    VERSION.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    REPORT.write_text(json.dumps({'stations':stations,'records':records,'errors':errors},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'[4/4] SUCCESS: stations={stations} records={records}',flush=True)

if __name__=='__main__': main()

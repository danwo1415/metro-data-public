Upload update_hk_service_hours.py and RUN-ONCE.sh to the ROOT of metro-data-public.
Then run exactly:

bash RUN-ONCE.sh

The script will not overwrite hong-kong-data.json unless it imports at least 60 stations and 100 direction records.

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
rm -rf __pycache__ cell-debug.txt mtr-station-test.html mtr-style-*.css mtr-script-*.js station-search.txt test_mtr_station.py
python -m pip install --quiet playwright
python -m playwright install chromium
python -u update_hk_service_hours.py
python -m json.tool hong-kong-data.json >/dev/null
python -m json.tool version.json >/dev/null
python -m json.tool service-hours-report.json >/dev/null
git add hong-kong-data.json version.json service-hours-report.json update_hk_service_hours.py RUN-ONCE.sh
git commit -m "Import Hong Kong official first and last train data" || true
git pull --rebase origin main
git push origin main
echo "DONE: public data updated and pushed. Reopen the app, then tap refresh."

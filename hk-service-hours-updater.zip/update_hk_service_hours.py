#!/usr/bin/env python3
"""Build serviceHours in hong-kong-data.json from MTR official station service-hours pages.
Run in the public metro-data-public repository.
"""
from __future__ import annotations
import argparse, json, re, sys, time
from pathlib import Path
from urllib.parse import urljoin
import requests
from bs4 import BeautifulSoup

BASE = "https://www.mtr.com.hk/en/customer/services/service_hours_search.php"
LINE_NAME_MAP = {
    "Airport Express": "AEL", "Tung Chung Line": "TCL", "Tuen Ma Line": "TML",
    "East Rail Line": "EAL", "Tsuen Wan Line": "TWL", "Island Line": "ISL",
    "Kwun Tong Line": "KTL", "Tseung Kwan O Line": "TKL",
    "South Island Line": "SIL", "Disneyland Resort Line": "DRL",
}
ALIASES = {
    "city": "HOK", "hong kong": "HOK", "central": "CEN", "admiralty": "ADM",
    "airport / asiaworld-expo": "AWE", "airport/asiaworld-expo": "AWE",
    "airport and asiaworld-expo": "AWE", "airport": "AIR", "asiaworld-expo": "AWE",
    "lo wu": "LOW", "lok ma chau": "LMC", "sheung shui": "SHS",
    "north point": "NOP", "po lam": "POA", "lohas park": "LHP",
    "wu kai sha": "WKS", "tuen mun": "TUM", "hung hom": "HUH",
    "kennedy town": "KET", "chai wan": "CHW", "tsuen wan": "TSW",
    "whampoa": "WHA", "tiu keng leng": "TIK", "south horizons": "SOH",
    "sunny bay": "SUN", "tung chung": "TUC",
}

def norm(s: str) -> str:
    s = re.sub(r"\s+", " ", s.replace("–", "-").replace("—", "-")).strip().lower()
    return s

def hhmm(s: str) -> str | None:
    m = re.search(r"\b(\d{2})(\d{2})\b", re.sub(r"\s", "", s))
    return f"{m.group(1)}:{m.group(2)}" if m else None

def station_catalog(session: requests.Session) -> list[tuple[str, str]]:
    r = session.get(BASE, params={"query_type":"search", "station":"1"}, timeout=30)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    out=[]
    for opt in soup.select("select option"):
        value=(opt.get("value") or "").strip(); name=opt.get_text(" ",strip=True)
        if value.isdigit() and name and name not in {"-", "Select"}:
            out.append((value,name))
    # Fallback for site markup changes: known numeric range, names parsed per page later.
    if not out:
        out=[(str(i),"") for i in range(1,121)]
    # de-duplicate
    seen=set(); ans=[]
    for x in out:
        if x[0] not in seen: seen.add(x[0]); ans.append(x)
    return ans

def map_station(name: str, english_to_code: dict[str,str]) -> str | None:
    n=norm(name)
    if n in ALIASES: return ALIASES[n]
    return english_to_code.get(n)

def parse_page(html: str, english_to_code: dict[str,str]):
    soup=BeautifulSoup(html,"html.parser")
    title=soup.find(["h1","h2"], string=re.compile("Service hours",re.I))
    page_text=soup.get_text(" ",strip=True)
    m=re.search(r"Service hours\s*-\s*([^|]+?)(?:Station opening hours|Search)",page_text,re.I)
    station_name=m.group(1).strip() if m else ""
    if not station_name:
        h=soup.find(string=re.compile(r"Service hours\s*-",re.I))
        if h: station_name=re.sub(r".*Service hours\s*-\s*","",h.strip(),flags=re.I)
    station_code=map_station(station_name,english_to_code)
    records=[]
    for table in soup.find_all("table"):
        rows=table.find_all("tr")
        if not rows: continue
        headers=[norm(x.get_text(" ",strip=True)) for x in rows[0].find_all(["th","td"])]
        if not any("first train" in h for h in headers) or not any("last train" in h for h in headers): continue
        # nearest preceding heading is line name
        heading=table.find_previous(["h2","h3","h4","strong"])
        line_name=heading.get_text(" ",strip=True) if heading else ""
        line_code=LINE_NAME_MAP.get(line_name)
        if not line_code:
            # search preceding text among known names
            prev=" ".join(x.get_text(" ",strip=True) for x in table.find_all_previous(["h2","h3","h4"],limit=3))
            line_code=next((v for k,v in LINE_NAME_MAP.items() if k in prev),None)
        if not line_code: continue
        for row in rows[1:]:
            cells=[x.get_text(" ",strip=True) for x in row.find_all(["th","td"])]
            if len(cells)<3: continue
            dest, first, last=cells[0],hhmm(cells[1]),hhmm(cells[2])
            dcode=map_station(dest,english_to_code)
            if dcode and first and last:
                records.append((line_code,dcode,first,last,dest))
    return station_code,station_name,records

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--data",default="hong-kong-data.json")
    ap.add_argument("--version",default="version.json")
    ap.add_argument("--delay",type=float,default=.15)
    args=ap.parse_args()
    p=Path(args.data); data=json.loads(p.read_text(encoding="utf-8"))
    english_to_code={norm(v):k for k,v in data["english"].items()}
    sess=requests.Session(); sess.headers["User-Agent"]="MetroRoutePlannerDataUpdater/1.0"
    catalog=station_catalog(sess)
    service={}; errors=[]; parsed=0
    for idx,(sid,_) in enumerate(catalog,1):
        try:
            r=sess.get(BASE,params={"query_type":"search","station":sid},timeout=30); r.raise_for_status()
            code,name,recs=parse_page(r.text,english_to_code)
            if not code or not recs: continue
            parsed+=1
            for line,dest,first,last,label in recs:
                service.setdefault(code,{}).setdefault(line,{})[dest]={"first":first,"last":last,"sourceStationId":int(sid)}
            print(f"[{idx}/{len(catalog)}] {code} {name}: {len(recs)}")
        except Exception as e:
            errors.append({"stationId":sid,"error":str(e)})
        time.sleep(args.delay)
    if parsed<70:
        raise SystemExit(f"Only {parsed} station pages parsed; refusing to overwrite data.")
    data["serviceHours"]=service
    data["updatedAt"]=time.strftime("%Y-%m-%d")
    old=str(data.get("version","hk-data-1")); m=re.search(r"(\d+)$",old)
    data["version"]=(old[:m.start(1)]+str(int(m.group(1))+1)) if m else old+"-2"
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    vp=Path(args.version)
    if vp.exists():
        v=json.loads(vp.read_text(encoding="utf-8")); v["version"]=data["version"]; v["updatedAt"]=data["updatedAt"]
        vp.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    Path("service-hours-report.json").write_text(json.dumps({"parsedStations":parsed,"serviceStations":len(service),"errors":errors},ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(f"Done: {len(service)} stations with service hours; version {data['version']}")

if __name__=="__main__": main()
